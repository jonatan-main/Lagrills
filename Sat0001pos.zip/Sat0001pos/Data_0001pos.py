# -*- coding: utf-8 -*-
"""
Created on Sat Apr 11 09:59:43 2020

@author: Mitzie
"""


import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression
from matplotlib.pyplot import figure

from mpl_toolkits.mplot3d import Axes3D

from mpl_toolkits import mplot3d

dispPos  = 1
dispPost = 1
dispDist = 0
dispReg  = 1
printReg = 1
printLyap= 0

plt.close('all')


#earth      = open("nEarth.txt","r"); sun  = open("nSun.txt","r"); jup = open("nJup.txt","r"); ven = open("nVen.txt","r")
#sat1       = open("nSat1.txt","r");  sat2 = open("nSat2.txt","r");
#---- No solar radiation
DistBase   = open("BaselineDist.txt","r");   JupiterVenus  = open("VenusJupiterDist.txt","r")
Venus      = open("VenusDist.txt","r");     Jupiter       = open("JupiterDist.txt","r");
#-----Solar rad ------
RadDistBase      = open("RAD_BaselineDist.txt","r"); RadJupiterVenus  = open("RAD_VenusJupiterDist.txt","r"); 
RadVenus         = open("RAD_VenusDist.txt","r");    RadJupiter       = open("RAD_JupiterDist.txt","r");
test = open("test.txt","r")

pB = open("Bpos.txt","r"); #pV = open("Vpos.txt","r"); pJ = open("Jpos.txt","r"); pVJ = open("VJpos.txt","r")
#rpB = open("rBpos.txt","r"); rpV = open("rVpos.txt","r"); rpJ = open("rJpos.txt","r"); rpVJ = open("rVJpos.txt","r")

sys = pB

#allPos = open("allPos.txt","r")

#----------------------- Satellite dist --------------------------------
def reader(file):
    num = []
    file = file;  txt = file.read();  txt = txt.split(",")
    #for x in range(len(txt)-1): 
    for x in range(1000):                     #<-- Number of iteration to look at
        curnum = float(txt[x])
        num.insert(x,curnum)
    value = num
    return value

#----------------------- Lyaponov exponent ----------------------------

def Lyaponov(data):
    data = data; dn = []; l = []; ldiv =[]; d0 = data[0]
    for n in range(len(data)):       
        dn.insert(n,data[n]/d0)
        l.insert(n,np.log(dn[n]))
        if n==0: 
            ldiv.insert(n,l[n]/1)
        else: 
            ldiv.insert(n,l[n]/n)
    N = len(ldiv); Sum = sum(ldiv); LyapExpAve = 1/(N) * Sum; dnlog = np.log(data)
    return LyapExpAve, dnlog

# -------------------- Regression -----------------------------

def regression(data):
    dnlog = data;
    x = np.array(list(range(len(dnlog)))).reshape((-1,1));  y = np.array(dnlog)
    model = LinearRegression().fit(x,y)
    r_sq = model.score(x,y)

    y_pred     = model.intercept_ + model.coef_ * x
    slope      = str(model.coef_); slope = slope.replace("[", "");   slope = slope.replace("]", "");  slopeFloat = float(slope)
    intercept  = str(model.intercept_); equation  = intercept + " + " + slope + "x" 

    return slope,y_pred, equation

#------------------------ Apply the lyapanov ----------------------------
def runData(data,printname,color):
    data = data;  satDistance = reader(data);  
 
    reg1 = regression(Lyaponov(satDistance)[1])
    plt.plot(Lyaponov(satDistance)[1],color)
    if printLyap == 1:           
        satl = Lyaponov(satDistance)[0]; 
        print(printname, "LyapExpAve:  ", satl);  
    if printReg == 1:      
        print(printname, "Reg slope: ", reg1[0] )
    if dispReg  == 1:
        plt.plot(reg1[1],color + '--',label = printname + reg1[2]); plt.legend(loc='lower right'); plt.xlabel("Iterations"); plt.ylabel ("ln(dn)")
    if dispDist == 1:
        #g = plt.figure(2)
        plt.plot(satDistance,color + '-',linewidth = 1); plt.xlabel("Iterations"); plt.ylabel ("Distance (AU)")
        #g.show()
    return reg1[0]



#-------------------- main code --------------------------------------

#----No radiation -------------

sBase = runData(DistBase, "Baseline:        ", 'b');    sVen    = runData(Venus,       "Venus:           ",'y'); 
sJup  = runData(Jupiter,  "Jupiter:         ", 'g');    sJupVen = runData(JupiterVenus,"Venus & Jupiter: ",'r');



#------with radiation ---------------
sRBase = runData(RadDistBase, "Rad + Baseline:       ", 'b');  sRVen = runData(RadVenus, "Rad + Venus:          ",'y'); 
sRJup  = runData(RadJupiter,  "Rad + Jupiter:        ", 'g'); sRJupVen = runData(RadJupiterVenus,"Rad + Venus & Jupiter:",'r'); 








#---------------------- Body function for pos --------------------------
if dispPos == 1:
    fig = plt.figure()
    ax = plt.axes(projection='3d') 


class body(object):
    def __init__(self, txt, size, color,offset):
        self.txt   = txt;       self.size  = size;       self.color = color; self.offset = offset

    def readSSV(self):
        self.count = 0
        self.xpos = []; self.ypos = []; self.zpos = [];
        self.idk = self.txt.read().splitlines()

        for line in self.idk:
            if 1 == 1:
                if self.idk[self.count] == self.idk[-1]:
                    continue
                split = line.split()
                self.count += 1    
                self.xpos.append(float(split[self.offset*3 + 1]))
                self.ypos.append(float(split[self.offset*3 + 2]))
                self.zpos.append(float(split[self.offset*3 + 3]))

    def use(self):
        #self.readPositions()
        self.readSSV()
        if dispPos == 1:
            ax.scatter3D(self.xpos, self.ypos, self.zpos, s = self.size, c = self.color)
    

S1  = body(sys,.1, "#080303", 2); S2  = body(sys, .1, "#D200DE",3)
Ear = body(sys,1 , "#3D9839",1); Sun = body(sys,50, "#F6FF05",0)
Jup = body(sys,6 , "#C18B00",5); Ven = body(sys, 1 , "#F0C577",4);
        

S1.use(); 
S2.use()
Ear.use()
Sun.use()
Jup.use()
Ven.use()


if dispPost == 1:
    plt.hold(True)
    plt.xlabel("Distance x (AU)")
    plt.ylabel("Distance y (AU)")
    plt.ylabel("Distance z (AU)")
    plt.title("The system")
    # Hide grid lines
    ax.grid(False)

# Hide axes ticks
    ax.set_xticks([])
    ax.set_yticks([])
#ax.set_zticks([])

    


# Save data for another code

import os.path

save_path = 'C:/Users/Mitzie/Documents/Project/ExportedData'

name_of_file = "001pos"

completeName = os.path.join(save_path, name_of_file+".txt")         

file1 = open(completeName, "w")


sNorm = sBase + "\n" + sVen + "\n" +  sJup  + "\n" + sJupVen 
sRad  = "\n" + ":" + "\n"  +   sRBase + "\n" + sRVen + "\n"  + "\n" +  sRJup + "\n" + sRJupVen + "\n"

sNorm = sBase + "," + sVen + "," +  sJup + "," +  sJupVen 
sRad  = ":" + sRBase + "," + sRVen + "," +  sRJup + ","+ sRJupVen 

#slopesNames = "\n" + ":" + "\n"  +"Base: " + sBase + "\n" + "Ven: " + sVen + "\n" + "Mars: " + sMar  + "\n" +  "Jup: " + sJup + "\n" + "VenMars: " + sVenMar  + "\n" + "MarJup: " + sMarJup + "\n" + "JupVen: " + sJupVen + "\n" + "VenJupMar: " + sVenJupMar

toFile = sNorm + sRad# + slopesNames
#print(toFile)

file1.write(toFile)

file1.close()
