# -*- coding: utf-8 -*-
"""
Created on Sat Apr 11 09:59:43 2020

@author: Mitzie
"""


import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression
from matplotlib.pyplot import figure

from mpl_toolkits.mplot3d import Axes3D

from mpl_toolkits import mplot3d

dispPos  = 0
dispDist = 0
dispReg  = 1

plt.close('all')


earth      = open("nEarth.txt","r"); sun  = open("nSun.txt","r"); jup = open("nJup.txt","r"); ven = open("nVen.txt","r")
sat1       = open("nSat1.txt","r");  sat2 = open("nSat2.txt","r"); mar = open("nMars.txt","r");
#---- No solar radiation
DistBase   = open("BaselineDist.txt","r")
Venus      = open("VenusDist.txt","r");     Jupiter      = open("JupiterDist.txt","r"); JupiterVenus  = open("VenusJupiterDist.txt","r")
Mars       = open("MarsDist.txt","r");  
VenusMars  = open("VenusMarsDist.txt","r"); MarsJupiter  = open("MarsJupiterDist.txt","r");
VenJupMar  = open("VenusJupiterMarsDist.txt","r")
#-----Solar rad ------
RadDistBase      = open("RAD_BaselineDist.txt","r")
RadVenus         = open("RAD_VenusDist.txt","r");        RadJupiter    = open("RAD_JupiterDist.txt","r"); RadMars = open("RAD_MarsDist.txt","r")
RadJupiterVenus  = open("RAD_VenusJupiterDist.txt","r"); RadVenusMars  = open("RAD_VenusMarsDist.txt","r"); RadMarsJupiter  = open("RAD_MarsJupiterDist.txt","r");
RadVenJupMar     = open("RAD_VenusJupiterMarsDist.txt","r")


#----------------------- Satellite dist --------------------------------
        
def reader(file):
    num = []
    file = file;  txt = file.read();  txt = txt.split(",")
    #for x in range(len(txt)-1): 
    for x in range(1000): 
        curnum = float(txt[x])
        num.insert(x,curnum)
    value = num
    return value

#----------------------- Lyaponov exponent ----------------------------

def Lyaponov(data):
    data = data; dn = []; l = []; ldiv =[]; d0 = data[0]
    for n in range(len(data)):       
        dn.insert(n,data[n]/d0)
        l.insert(n,np.log(dn[n]))
        if n==0: 
            ldiv.insert(n,l[n]/1)
        else: 
            ldiv.insert(n,l[n]/n)
    N = len(ldiv); Sum = sum(ldiv); LyapExpAve = 1/(N) * Sum; dnlog = np.log(data)
    return LyapExpAve, dnlog

# -------------------- Regression -----------------------------

def regression(data):
    dnlog = data;

    x = np.array(list(range(len(dnlog)))).reshape((-1,1));  y = np.array(dnlog)
    model = LinearRegression().fit(x,y)

    r_sq = model.score(x,y)
    #print('coefficient of determination:', r_sq)
    y_pred     = model.intercept_ + model.coef_ * x
    slope      = str(model.coef_); slope = slope.replace("[", "");   slope = slope.replace("]", "");  slopeFloat = float(slope)
    intercept  = str(model.intercept_); equation  = intercept + " + " + slope + "x" 

    return slope,y_pred, equation

#------------------------ Apply the lyapanov ----------------------------
def runData(data,printname,color):
    data = data;  satDistance = reader(data);  
    satl = Lyaponov(satDistance)[0];  
    reg1 = regression(Lyaponov(satDistance)[1])
    #f = plt.figure(1)
    
    plt.plot(Lyaponov(satDistance)[1],color)
    
    #f.show()
    print(printname, "LyapExpAve:  ", satl);  
    print(printname, "Reg slope: ", reg1[0] )
    if dispReg  == 1:
        plt.plot(reg1[1],color + '--',label = printname + reg1[2]); plt.legend(loc='lower right'); plt.xlabel("Iterations"); plt.ylabel ("ln(dn)")
    if dispDist == 1:
        g = plt.figure(2)
        plt.plot(satDistance,color + '-',linewidth = 1); plt.xlabel("Iterations"); plt.ylabel ("Distance (AU)")
        g.show()
    return reg1[0]
#-------------------- main code --------------------------------------

#----No radiation -------------

sBase = runData(DistBase,    "Baseline:  ", 'b');
sVen = runData(Venus, "Venus:     ",'y'); 


sMar = runData(Mars, "Mars:          ",'r');                  sJup    = runData(Jupiter, "Jupiter:      ", 'g'); 
sJupVen = runData(JupiterVenus,"Venus & Jupiter:      ",'r'); sVenMar = runData(VenusMars,"Venus & Mars: ",'r'); sMarJup = runData(MarsJupiter,"Jupiter & Mars:       ",'r')  
sVenJupMar = runData(VenJupMar,"Ven & Jup & Mar:      ",'r')


#------with radiation ---------------
sRBase = runData(RadDistBase,    "Rad + Baseline        ", 'b'); sRVen = runData(RadVenus, "Rad + Venus:          ",'y'); 
sRJup = runData(RadJupiter, "Rad + Jupiter:        ", 'g'); sRMar = runData(RadMars, "Rad + Mars:             ", 'r')

sRJupVen = runData(RadJupiterVenus,"Rad + Venus & Jupiter:",'r')

sRVenMar = runData(RadVenusMars,"Rad + Venus & Mars:   ",'r'); sRMarJup = runData(RadMarsJupiter,"Rad + Jupiter & Mars: ",'r')  
sRVenJupMar = runData(RadVenJupMar,"Rad + Ven & Jup & Mar:",'r')








#---------------------- Body function for pos --------------------------
if dispPos == 1:
    fig = plt.figure()
    ax = plt.axes(projection='3d') 


class body(object):
    def __init__(self, txt, size, color):
        self.txt   = txt;       self.size  = size;       self.color = color
        
    def readPositions(self):
        fss = self.txt;      f1 = fss.read()
        f1 = f1.replace("[", "");   f1 = f1.replace("]", "");      xyz = f1.split(",")
        num = []
    
        for x in range(len(xyz)-1): 
            curnum = float(xyz[x])
            num.insert(x,curnum)           
    
        self.xpos = num[0::3];    self.ypos = num[1::3];    self.zpos = num[2::3]        
        #print(self.xpos)
        if dispPos == 1:
            ax.scatter3D(self.xpos, self.ypos, self.zpos, s = self.size, c = self.color)
        
        
    def use(self):
        self.readPositions()

    

S1  = body(sat1 , .1, "#080303"); S2  = body(sat2 , .1, "#D200DE")
Ear = body(earth, 1 , "#3D9839"); Sun = body(sun  , 50, "#F6FF05")
Jup = body(jup  , 6 , "#C18B00"); Ven = body(ven  , 1 , "#F0C577"); Mar =body(mar  , 1 , "#9B0000")
        


#S1.use(); 
#S2.use()
#Ear.use()
#Sun.use()
#Jup.use()
Ven.use()
#Mar.use()
    














if dispPos == 1:
    plt.xlabel("Distance x (AU)")
    plt.ylabel("Distance y (AU)")
    plt.ylabel("Distance z (AU)")
    plt.title("The system")
    # Hide grid lines
    ax.grid(False)

# Hide axes ticks
    ax.set_xticks([])
    ax.set_yticks([])
#ax.set_zticks([])





import os.path

save_path = 'C:/Users/Mitzie/Documents/Project/ExportedData'

name_of_file = "0001pos"

completeName = os.path.join(save_path, name_of_file+".txt")         

file1 = open(completeName, "w")




sNorm = sBase + "\n" + sVen + "\n" + sMar  + "\n" +  sJup + "\n" + sVenMar  + "\n" + sMarJup + "\n" + sJupVen + "\n" + sVenJupMar
sRad  = "\n" + ":" + "\n"  +   sRBase + "\n" + sRVen + "\n" + sRMar  + "\n" +  sRJup + "\n" + sRVenMar  + "\n" + sRMarJup + "\n" + sRJupVen + "\n" + sRVenJupMar
#print(data)


sNorm = sBase + "," + sVen + "," + sMar  + "," +  sJup + "," + sVenMar  + "," + sMarJup + "," + sJupVen + "," + sVenJupMar
sRad  = ":" + sRBase + "," + sRVen + "," + sRMar  + "," +  sRJup + "," + sRVenMar  + "," + sRMarJup + "," + sRJupVen + "," + sRVenJupMar


slopesNames = "\n" + ":" + "\n"  +"Base: " + sBase + "\n" + "Ven: " + sVen + "\n" + "Mars: " + sMar  + "\n" +  "Jup: " + sJup + "\n" + "VenMars: " + sVenMar  + "\n" + "MarJup: " + sMarJup + "\n" + "JupVen: " + sJupVen + "\n" + "VenJupMar: " + sVenJupMar


toFile = sNorm + sRad# + slopesNames

file1.write(toFile)

file1.close()
